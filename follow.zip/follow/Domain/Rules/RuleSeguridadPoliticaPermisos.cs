namespace FollowMotors.Domain.Rules.Seguridad;

/// <summary>Centraliza las decisiones de rol que protegen operaciones de negocio.</summary>
public sealed class PoliticaPermisos : IPoliticaPermisos
{
    /// <summary>Determina si la cuenta puede registrar clientes presencialmente.</summary>
    public bool PuedeRegistrarClientes(string rol) => rol is "GERENTE" or "EMPLEADO";

    /// <summary>Determina si la cuenta puede desactivar a un cliente.</summary>
    public bool PuedeDesactivarCliente(string rol) => rol == "GERENTE";

    /// <summary>Determina si puede registrar personal o consultar auditoría.</summary>
    public bool PuedeAdministrarPersonal(string rol) => rol == "GERENTE";

    /// <summary>Determina si puede recibir motocicletas y cobrar revisiones.</summary>
    public bool PuedeGestionarAtenciones(string rol) => rol is "GERENTE" or "EMPLEADO";

    /// <summary>Determina si una persona puede registrar un diagnóstico asignado.</summary>
    public bool PuedeDiagnosticar(string rol, ulong? empleadoId, ulong mecanicoAsignadoId) =>
        rol == "GERENTE" || (rol == "EMPLEADO" && empleadoId == mecanicoAsignadoId);

    /// <summary>Evita mostrar a un cliente información de una moto ajena.</summary>
    public bool PuedeConsultarPropiedad(string rol, ulong? clienteActualId, ulong propietarioId) =>
        rol is "GERENTE" or "EMPLEADO" || (rol == "CLIENTE" && clienteActualId == propietarioId);
}
